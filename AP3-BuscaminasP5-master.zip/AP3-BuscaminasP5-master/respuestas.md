## Respuesta punto 6

## Respuesta punto 8

## Respuesta punto ...